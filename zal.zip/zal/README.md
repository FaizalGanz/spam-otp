## Spam Multi OTP
> apa itu multi otp?

> spam multi otp adalah tools: Spamming Multi operator yang open source di mana setiap komunitas dapat mengedit nya sedemikian rupa

## Instalasi
```
$ cd
$ pkg update -y && pkg upgrade -y
$ pkg install git -y
$ pkg install python -y
$ pip install requests
$ git clone https://github.com/DARK-02/Multi-Otp
```
## Eksekusi
```python3
$ cd Multi-Otp
$ python3 run.py
```
